@charset "UTF-8";

 * ckeditor editor测试
 * images 共用的图片
 * js  共用的JavaScript
 * css 共用的css
 * skins 皮肤包