/*@charset "UTF-8";*/
drop database if exists firstsite;
create database firstsite;
use firstsite;        