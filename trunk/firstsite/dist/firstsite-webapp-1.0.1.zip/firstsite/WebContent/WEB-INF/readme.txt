@charset "UTF-8";

= 相关目录=
 # config 配置目录,配置的原则优先使用WEB-INF下的目录,其次选择classes中的内容
 # data 数据文件存在的目录


