@charset "UTF-8";

=增加一下内容到功能能列表=
  发件
 	../message/new.jsp  写新邮件
 	../message/sent.jsp  已发邮件
   发件
 	../message/new.jsp  写新邮件
 	../message/sent.jsp  已发邮件
 	
=增加系统默认数据 = 
  	Init.main(String[] args);
  	
  