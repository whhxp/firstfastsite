@charset "UTF-8";

1.执行 init.sql
2.