/*@charset "UTF-8";*/

drop database if exists firstfastsite;
create database firstfastsite;
use firstfastsite;          